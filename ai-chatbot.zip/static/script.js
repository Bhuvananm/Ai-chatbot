const input = document.getElementById('input');
const send = document.getElementById('send');
const messages = document.getElementById('messages');

function appendMessage(text, who) {
  const div = document.createElement('div');
  div.className = 'msg ' + (who === 'user' ? 'user' : 'assistant');
  if (who === 'user') {
    div.innerHTML = `<div class="meta">You</div><div>${escapeHtml(text)}</div>`;
  } else {
    div.innerHTML = `<div class="meta">Assistant</div><div class="assistant">${escapeHtml(text)}</div>`;
  }
  messages.appendChild(div);
  messages.scrollTop = messages.scrollHeight;
}

function escapeHtml(unsafe) {
  return unsafe.replace(/[&<"'>]/g, function(m) {
    return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m];
  });
}

async function sendMessage() {
  const text = input.value.trim();
  if (!text) return;
  appendMessage(text, 'user');
  input.value = '';
  appendMessage('Thinking...', 'assistant');
  try {
    const res = await fetch('/chat', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({message: text})
    });
    const j = await res.json();
    // remove last 'Thinking...' message
    const last = messages.lastElementChild;
    if (last && last.textContent.includes('Thinking')) last.remove();
    if (j.reply) {
      appendMessage(j.reply, 'assistant');
    } else if (j.error) {
      appendMessage('Error: ' + j.error, 'assistant');
    } else {
      appendMessage('No reply received.', 'assistant');
    }
  } catch (e) {
    appendMessage('Network error: ' + e.message, 'assistant');
  }
}

send.addEventListener('click', sendMessage);
input.addEventListener('keydown', (e) => { if (e.key === 'Enter') sendMessage(); });
