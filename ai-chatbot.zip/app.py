import os
from flask import Flask, render_template, request, jsonify
import requests

app = Flask(__name__, static_folder='static', template_folder='templates')

OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY')
if not OPENAI_API_KEY:
    # It's okay to run without an API key for static preview, but chat will fail.
    app.logger.warning("OPENAI_API_KEY not set. Chat will not work until it's provided.")

OPENAI_API_URL = "https://api.openai.com/v1/chat/completions"
MODEL = "gpt-3.5-turbo"

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    data = request.get_json() or {}
    message = data.get('message', '').strip()
    if not message:
        return jsonify({"error": "Empty message"}), 400
    if not OPENAI_API_KEY:
        return jsonify({"error": "Server missing OPENAI_API_KEY"}), 500

    headers = {
        "Authorization": f"Bearer {OPENAI_API_KEY}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": MODEL,
        "messages": [
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": message}
        ],
        "max_tokens": 500,
        "temperature": 0.7
    }
    try:
        resp = requests.post(OPENAI_API_URL, headers=headers, json=payload, timeout=30)
        resp.raise_for_status()
        j = resp.json()
        reply = j.get('choices', [{}])[0].get('message', {}).get('content', '')
        return jsonify({"reply": reply})
    except requests.exceptions.RequestException as e:
        app.logger.error("OpenAI request failed: %s", e)
        return jsonify({"error": "OpenAI API request failed."}), 502

if __name__ == '__main__':
    app.run(debug=True)
